// ========================================
// 1. PRODUCT DATA
// ========================================

const products = [

   {
    id: 1, name: "Lotus floor lamp ", brand: "Unbranded", category: "Home Appliances", categories: ["Home Appliances", "Electronics"],
    price: 28000, rating: 5, badge: "Personal Care",
    image: "https://i.pinimg.com/736x/c8/d8/00/c8d8007f6a6429778c8eacc959a117ad.jpg",
    description: "A compact electric hair dryer for convenient everyday hair styling at home.", featured: false, newArrival: true, bestSeller: true
  },

  {
    id: 2, name: "Zero Smart Watch", brand: "Zero", category: "Accessories", categories: ["Accessories"],
    price: 6990, rating: 4.8, badge: "Best Seller",
    image: "https://watchcollection.pk/wp-content/uploads/2026/07/Zero-Edge-Smartwatch-Price-in-Pakistan.webp",
    description: "A stylish smart watch with activity tracking, notifications and a modern everyday design.", featured: true, newArrival: true, bestSeller: true
  },
  {
    id: 3, name: "Boys contrast demin Jacket", brand: "Breakout", category: "Clothing", categories: ["Clothing"],
    price: 5200, rating: 3.9, badge: "New",
    image: "https://cdn.shopify.com/s/files/1/0202/5884/8822/files/K26WJ601-GRN_1.jpg?v=1791528058",
    description: "A casual denim jacket that can be paired with jeans, trousers and everyday outfits.", featured: true, newArrival: true, bestSeller: false
  },
  {
    id: 4, name: "Men's monochrome sneaker", brand: "NDURE", category: "Shoes", categories: ["Shoes"],
    price: 4399, rating: 4.7, badge: "Popular",
    image: "https://www.ndure.com/cdn/shop/files/5_d8c4fe1d-88b6-437e-883c-8be5c0738037.jpg?v=1787129238&width=493",
    description: " running sneaker, comfortable design for walking and workouts.", featured: true, newArrival: false, bestSeller: true
  },
  {
    id: 5, name: "Party wear court Shoes", brand: "Insignia", category: "Shoes", categories: ["Shoes"],
    price: 11950, rating: 4.4, badge: "New",
    image: "https://insignia.com.pk/cdn/shop/files/I47164_GOLDENc_ca4de64d-f031-4227-9a10-014b86aa4a30.jpg?v=1760362503&width=1445",
    description: "party wear shoes  made with the lustrous leather make glamour look.", featured: false, newArrival: true, bestSeller: false
  },
  {
    id: 6, name: "Opéra Timbre Lady Wrist Watch", brand: " Pierre Cardin paris", category: "Accessories", categories: ["Accessories"],
    price: 49511, rating: 4.6, badge: "For Her",
    image: "https://www.pierrecardinwatches.com/cdn/shop/files/CF.1012.MU.9CR_3_5f77fcba-3511-41b7-b098-0e637600f0f0.jpg?v=1765642649&width=1500",
    description: " two-tone gold and silver , Japanese quartz movement, and a matching two-tone stainless steel metal strap.", featured: true, newArrival: false, bestSeller: false
  },
  {
    id: 7, name: "Sony Wireless Headphones", brand: "Sony", category: "Electronics", categories: ["Electronics"],
    price: 18000, rating: 4.9, badge: "Top Rated",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTn3IdX0P6kznsyQvTyOPLUYmUCWyXR8kzRt5L2BfC2ULCeOnpLdNar-sg&s=10",
    description: "Over-ear wireless headphones designed for immersive sound and comfortable listening.", featured: true, newArrival: true, bestSeller: true
  },

  {
    id: 8, name: " Quiet Cool Mist Humidifier", brand: "Drreo", category: "Electronics", categories: ["Electronics"],
    price: 5200, rating: 4.4, badge: "New",
    image: "https://i.pinimg.com/1200x/18/f9/b0/18f9b004d047426e2c8ae79ad12cba28.jpg",
    description: "This DREO cool mist humidifier literally saved your sleep with its super quiet 26dB operation", featured: false, newArrival: true, bestSeller: false
  },
 
  {
    id: 9, name: "Ladies Sunglasses", brand: "Unbranded", category: "Accessories", categories: ["Accessories"],
    price: 489, rating: 3.0, badge: "For Her",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEaOH-pqmL5_lds8gojrhuMnMYefPhbm1Q0_lCt4PcFxKLTKGjhnpyScVm&s=10",
    description: "Lightweight fashionable sunglasses that add a finishing touch to everyday looks.", featured: false, newArrival: true, bestSeller: false
  },
   {
    id: 10, name: "Digital Air Fryer", brand: "Anex", category: "Home Appliances", categories: ["Home Appliances", "Electronics"],
    price: 36563, rating: 5, badge: "Popular",
    image: "https://i.pinimg.com/736x/cf/0e/bc/cf0ebc790f188c91256cf5c4f6ef1284.jpg",
    description: "A digital air fryer for preparing crispy meals with convenient temperature and timer controls.", featured: false, newArrival: false, bestSeller: true
  },
  
  {
    id: 11, name: "Printed Pakistani Lawn Suit", brand: "Limelight", category: "Clothing", categories: ["Clothing"],
    price: 4899, rating: 4.3, badge: "Pakistani Wear",
    image: "https://www.limelight.pk/cdn/shop/files/U5030SU-3PC-489-3PieceLawnSuit-Embroidered_Unstitched_5_bbe63a83-624a-4ea1-ba7c-9994cca432d9.jpg?v=1782735059&width=1946",
    description: "A colourful Pakistani lawn suit for daily wear, with a comfortable fabric and traditional-inspired print.", featured: false, newArrival: true, bestSeller: false
  },
  {
    id: 12, name: "Home Coffee Maker", brand: "Philips", category: "Home Appliances", categories: ["Home Appliances", "Electronics"],
    price: 15500, rating: 4.7, badge: "Featured",
    image: "https://i.pinimg.com/736x/e0/b2/37/e0b2374ae56771c7293df6f1f0ea8586.jpg",
    description: "A compact electric coffee machine for preparing fresh coffee at home with simple controls.", featured: true, newArrival: false, bestSeller: true
  },
  {
    id: 13, name: "Embroidered Women's Kurti", brand: "Khaadi", category: "Clothing", categories: ["Clothing"],
    price: 10000, rating: 4.6, badge: "New",
    image: "https://pk.khaadi.com/dw/image/v2/BJTG_PRD/on/demandware.static/-/Sites-khaadi-master-catalog/default/dw3318e656/images/hi-res/2-26-409-a-f1_multi_1.jpg?sw=800&sh=1200",
    description: "A graceful women's kurti inspired by Pakistani casual fashion, suitable for everyday use.", featured: true, newArrival: true, bestSeller: false
  },
  {
    id: 14, name: "Three Piece Embroidered Suit", brand: "Sapphire", category: "Clothing", categories: ["Clothing"],
    price: 6900, rating: 4.8, badge: "Trending",
    image: "https://pk.sapphireonline.pk/dw/image/v2/BKSB_PRD/on/demandware.static/-/Sites-sapphire-master-catalog/default/dw58c9cbae/images/Nov26/Unstitched9Nov/0ELX25V1016B_2.JPG?sw=1000&sh=1200",
    description: "A three-piece women's outfit with an elegant embroidered look for family gatherings and occasions.", featured: true, newArrival: true, bestSeller: true
  },
  {
    id: 15, name: "Traditional Women's Khussa", brand: "Stylo", category: "Shoes", categories: ["Shoes"],
    price: 2210, rating: 4.1, badge: "For Her",
    image: "https://int.stylo.pk/cdn/shop/files/EC861087_1_1fabaa58-e464-4fb2-87d4-0ca7280f1b05.jpg?v=1772532660&width=1080",
    description: "Traditional-inspired women's khussa footwear to pair with eastern and festive outfits.", featured: false, newArrival: true, bestSeller: false
  },
  {
    id: 16, name: "Women's Everyday Handbag", brand: "Unze london", category: "Accessories", categories: ["Accessories"],
    price: 5200, rating: 4.5, badge: "For Her",
    image: "https://unze.com.pk/cdn/shop/files/bg9436e_ed597601-5f05-4467-91ef-7bf5709252a1.jpg?v=1777883042",
    description: "A practical and stylish handbag with space for everyday essentials.", featured: true, newArrival: false, bestSeller: true
  },
  {
    id: 17, name: "Women's Jewelry Set", brand: "Unbranded", category: "Accessories", categories: ["Accessories"],
    price: 3800, rating: 3.9, badge: "For Her",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRubqh2F76Ba8icUtpOvVYI32ioLQ1wzv0-ap0zkCkKX4pHRoYXtlO6vMg&s=10",
    description: "A decorative jewelry set designed to complement eastern dresses and party outfits.", featured: false, newArrival: true, bestSeller: false
  },
  {
    id: 18, name: "Women's Casual Sneakers", brand: "Nike", category: "Shoes", categories: ["Shoes"],
    price: 4200, rating: 4.3, badge: "For Her",
    image: "https://static.nike.com/a/images/t_web_pw_592_v2/f_auto/u_9ddf04c7-2a9a-4d76-add1-d15af8f0263d,c_scale,fl_relative,w_1.0,h_1.0,fl_layer_apply/01adc065-6b97-431d-82c5-cb34a20d5215/WMNS+NIKE+DUNK+LOW.png",
    description: "Comfortable casual sneakers for daily walking, university and relaxed outfits.", featured: false, newArrival: true, bestSeller: false
  },
  {
    id: 19, name: "Dawlance Microwave Oven", brand: "Dawlance", category: "Home Appliances", categories: ["Home Appliances", "Electronics"],
    price:  25999, rating: 4.4, badge: "Home Essential",
    image: "https://www.dawlance.com.pk/medias/1280x720-2.png?context=bWFzdGVyfHJvb3R8MTI4MTMxNnxpbWFnZS9wbmd8YURnNEwyZzBNUzh4TURVNU1UTXhNREE0TmpFM05DOHhNamd3ZURjeU1DMHlMbkJ1Wnd8MTI4NWJmMmVmZWNiOGY4MWMxYTRhOTc0ODU2ZDdhYmY2ZjYxYjhkOGE4NTc4N2Y1MGNlYjNiOGJlMjRhOTVjZA",
    description: "A convenient microwave oven for reheating and preparing everyday meals in the kitchen.", featured: true, newArrival: false, bestSeller: true
  },

  {
    id: 20, name: "Samsung Galaxy Buds", brand: "Samsung", category: "Electronics", categories: ["Electronics"],
    price: 4500, rating: 4.5, badge: "Featured",
    image: "https://i.pinimg.com/736x/5b/00/9e/5b009ef469956d139aa5cab3df7f6a3b.jpg",
    description: "Wireless earbuds with clear sound, a comfortable fit and a compact charging case for everyday listening.", featured: true, newArrival: false, bestSeller: true
  },
  {
    id: 21, name: "Philips Kitchen Blender", brand: "Philips", category: "Home Appliances", categories: ["Home Appliances", "Electronics"],
    price: 9500, rating: 4.2, badge: "Kitchen Essential",
    image: "https://i.pinimg.com/1200x/fc/70/ad/fc70ad05593895f7593952aa6fb70cfe.jpg",
    description: "An electric kitchen blender for preparing smoothies, sauces and everyday recipes.", featured: false, newArrival: false, bestSeller: true
  },
  {
    id: 22, name: "Men's Cotton Kurta Shalwar", brand: "J.", category: "Clothing", categories: ["Clothing"],
    price: 3800, rating: 4.0, badge: "Eastern Wear",
    image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGj26ixRDibzBF3A7VsH8gUS5uHnfu9BamBQwyOdZ1YS8mKYWW9sIpGhg&s=10",
    description: "A simple men's eastern outfit inspired by Pakistani kurta shalwar styles.", featured: false, newArrival: false, bestSeller: true
  },
 
];

// ---------------------------------------------------
// 2. VARIABLES AND LOCAL STORAGE
// -----------------------------------
 
let cart = JSON.parse(localStorage.getItem("shopEaseCart")) || []; //ya save data ya khali array 
let wishlist = JSON.parse(localStorage.getItem("shopEaseWishlist")) || []; 

let currentSlide = 0;
let slideTimer;

let currentTab = "all";
let selectedCategory = "All";
let selectedProduct = null; //product ka data jo user dekhy ga es mn ho ga  description ur wo jo baki 
let detailQuantity = 1;// pehly 1 baad mn user +1 kr k brha skta 

let currentUser = JSON.parse(localStorage.getItem("shopEaseUser")) || null;

const productGrid = document.getElementById("productGrid");
const searchInput = document.getElementById("searchInput");

// --------------------------------------------------------------------
// 3. HELPER FUNCTIONS
// ---------------------------------------------------------------

function formatPrice(price) {
  return "Rs. " + price.toLocaleString("en-PK"); // number ko readable format mn convert krna
}

function saveCart() {
  localStorage.setItem("shopEaseCart", JSON.stringify(cart));// setitem data store k liy , data ko string mn kro not array
}

function saveWishlist() {
  localStorage.setItem("shopEaseWishlist", JSON.stringify(wishlist));
}

function showToast(message) { // product add to card , product add to wishlist etc
  let toast = document.querySelector(".toast");

  if (!toast) {
    toast = document.createElement("div");
    toast.className = "toast";
    document.body.appendChild(toast);//html mn dalo
  }

  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(window.toastTimer);

  window.toastTimer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2500);
}

function openModal(id) {
  document.getElementById(id).classList.add("show");
  document.body.style.overflow = "hidden";
}

function closeModal(id) {
  document.getElementById(id).classList.remove("show");

  if (!document.querySelector(".modal.show")) {
    document.body.style.overflow = "";
  }
}

// ========================================
// 4. PRODUCT DISPLAY
// ========================================

function renderProducts(list = products) {
  productGrid.innerHTML = "";

  document.getElementById("resultCount").textContent =
    "Showing " + list.length + " products";

  document.getElementById("emptyMessage").hidden = list.length !== 0;

  list.forEach((product) => {
    const isLiked = wishlist.includes(product.id);

    const card = document.createElement("div");
    card.className = "product-card";
    card.dataset.productCard = product.id;
    card.setAttribute("role", "button");
    card.setAttribute("tabindex", "0");
    card.setAttribute("aria-label", "View details for " + product.name);

    card.innerHTML = `
            <div class="product-image">

                <img src="${product.image}" alt="${product.name}" loading="lazy">

                <span class="product-badge">${product.badge}</span>

                <button class="wishlist-heart ${isLiked ? "liked" : ""}"
                    data-wishlist="${product.id}">
                    <i class="${isLiked ? "fas" : "far"} fa-heart"></i>
                </button>

            </div>

            <div class="product-info">

                <span class="product-brand">${product.brand}</span>

                <h3>${product.name}</h3>

                <div class="rating">
                    ${"★".repeat(Math.round(product.rating))}
                    <span>(${product.rating})</span>
                </div>

                <div class="product-price">
                    ${formatPrice(product.price)}
                </div>

                <div class="product-buttons">
                    <button class="add-btn" data-add="${product.id}">
                        <i class="fas fa-shopping-cart"></i> Add to Cart
                    </button>

                    <button class="details-btn" data-details="${product.id}">
                        Details
                    </button>
                </div>

            </div>
        `;

    productGrid.appendChild(card);
  });
}

// ========================================
// 5. SEARCH AND FILTER
// ========================================

function filterProducts() {
  const searchValue = searchInput.value.toLowerCase().trim();

  const maxPrice = Number(document.getElementById("priceFilter").value);

  const brand = document.getElementById("brandFilter").value;

  const minRating = Number(document.getElementById("ratingFilter").value);

  let filtered = products.filter((product) => {
    const matchesSearch =
      product.name.toLowerCase().includes(searchValue) ||
      product.brand.toLowerCase().includes(searchValue) ||
      (product.categories || [product.category]).some((category) =>
        category.toLowerCase().includes(searchValue)
      );

    const productCategories = product.categories || [product.category];
    const matchesCategory =
      selectedCategory === "All" || productCategories.includes(selectedCategory);

    const matchesPrice = product.price <= maxPrice;

    const matchesBrand = brand === "All" || product.brand === brand;

    const matchesRating = product.rating >= minRating;

    let matchesTab = true;

    if (currentTab === "featured") {
      matchesTab = product.featured;
    }

    if (currentTab === "new") {
      matchesTab = product.newArrival;
    }

    if (currentTab === "best") {
      matchesTab = product.bestSeller;
    }

    return (
      matchesSearch &&
      matchesCategory &&
      matchesPrice &&
      matchesBrand &&
      matchesRating &&
      matchesTab
    );
  });

  const sortValue = document.getElementById("sortFilter").value;

  if (sortValue === "low") {
    filtered.sort((a, b) => a.price - b.price);
  }

  if (sortValue === "high") {
    filtered.sort((a, b) => b.price - a.price);
  }

  if (sortValue === "rating") {
    filtered.sort((a, b) => b.rating - a.rating);
  }

  renderProducts(filtered);
}

// Search events

searchInput.addEventListener("input", filterProducts);

document.getElementById("searchBtn").addEventListener("click", () => {
  filterProducts();
  document.getElementById("products").scrollIntoView({
    behavior: "smooth",
  });
});

// Category filters

document.querySelectorAll('input[name="category"]').forEach((input) => {
  input.addEventListener("change", () => {
    selectedCategory = input.value;
    filterProducts();
  });
});

// Price filter

document.getElementById("priceFilter").addEventListener("input", (event) => {
  document.getElementById("priceValue").textContent = Number(
    event.target.value,
  ).toLocaleString("en-PK");

  filterProducts();
});

// Brand filter

document
  .getElementById("brandFilter")
  .addEventListener("change", filterProducts);

// Rating filter

document
  .getElementById("ratingFilter")
  .addEventListener("change", filterProducts);

// Sorting

document
  .getElementById("sortFilter")
  .addEventListener("change", filterProducts);

// Product tabs

document.querySelectorAll(".tab-btn").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((btn) => {
      btn.classList.remove("active");
    });

    button.classList.add("active");

    currentTab = button.dataset.type;

    filterProducts();
  });
});

// Reset filters

document.getElementById("resetFilters").addEventListener("click", () => {
  selectedCategory = "All";
  currentTab = "all";

  searchInput.value = "";

  document.getElementById("priceFilter").value = 100000;
  document.getElementById("priceValue").textContent = "100,000";

  document.getElementById("brandFilter").value = "All";
  document.getElementById("ratingFilter").value = "0";
  document.getElementById("sortFilter").value = "default";

  document.querySelector('input[name="category"][value="All"]').checked = true;

  document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.type === "all");
  });

  filterProducts();
});

// Category cards

document.querySelectorAll(".category-card").forEach((card) => {
  card.addEventListener("click", () => {
    selectedCategory = card.dataset.category;

    document.querySelector(
      `input[name="category"][value="${selectedCategory}"]`,
    ).checked = true;

    currentTab = "all";

    document.querySelectorAll(".tab-btn").forEach((btn) => {
      btn.classList.toggle("active", btn.dataset.type === "all");
    });

    filterProducts();

    document.getElementById("products").scrollIntoView({
      behavior: "smooth",
    });
  });
});

// ========================================
// 6. ADD TO CART
// ========================================

function addToCart(productId, quantity = 1) {
  const product = products.find((item) => item.id === productId);

  if (!product) return;

  const existingItem = cart.find((item) => item.id === productId);

  if (existingItem) {
    existingItem.quantity += quantity;
  } else {
    cart.push({
      id: productId,
      quantity: quantity,
    });
  }

  saveCart();
  updateCartCount();

  showToast(product.name + " added to cart!");
}

// ========================================
// 7. CART COUNT AND DISPLAY
// ========================================

function updateCartCount() {
  const totalItems = cart.reduce((total, item) => total + item.quantity, 0);

  document.getElementById("cartCount").textContent = totalItems;
}

function renderCart() {
  const cartItems = document.getElementById("cartItems");

  cartItems.innerHTML = "";

  if (cart.length === 0) {
    cartItems.innerHTML =
      '<p class="empty-message">Your shopping cart is empty!</p>';
  }

  cart.forEach((item) => {
    const product = products.find((p) => p.id === item.id);

    if (!product) return;

    const row = document.createElement("div");
    row.className = "cart-row";

    row.innerHTML = `

            <img src="${product.image}" alt="${product.name}">

            <div>
                <h4>${product.name}</h4>

                <p>${formatPrice(product.price)}</p>

                <div class="cart-quantity">

                    <button data-cart-action="decrease" data-id="${product.id}">-</button>

                    <span>${item.quantity}</span>

                    <button data-cart-action="increase" data-id="${product.id}">+</button>

                </div>

            </div>

            <div>
                <strong>${formatPrice(product.price * item.quantity)}</strong>
                <br>
                <button class="remove-btn" data-remove="${product.id}">
                    Remove
                </button>
            </div>

        `;

    cartItems.appendChild(row);
  });

  updateCartTotal();
}

// ========================================
// 8. QUANTITY MANAGEMENT
// ========================================

function changeCartQuantity(productId, action) {
  const item = cart.find((p) => p.id === productId);

  if (!item) return;

  if (action === "increase") {
    item.quantity++;
  }

  if (action === "decrease") {
    item.quantity--;

    if (item.quantity <= 0) {
      cart = cart.filter((p) => p.id !== productId);
    }
  }

  saveCart();

  updateCartCount();

  renderCart();

  filterProducts();
}

// ========================================
// 9. REMOVE FROM CART
// ========================================

function removeFromCart(productId) {
  cart = cart.filter((item) => item.id !== productId);

  saveCart();

  updateCartCount();

  renderCart();

  showToast("Product removed from cart!");
}

// ========================================
// 10. TOTAL BILL CALCULATION
// ========================================

function updateCartTotal() {
  let subtotal = 0;

  cart.forEach((item) => {
    const product = products.find((p) => p.id === item.id);

    if (product) {
      subtotal += product.price * item.quantity;
    }
  });

  const delivery = subtotal === 0 || subtotal >= 10000 ? 0 : 250;

  const total = subtotal + delivery;

  document.getElementById("cartSubtotal").textContent = formatPrice(subtotal);

  document.getElementById("deliveryFee").textContent = formatPrice(delivery);

  document.getElementById("cartTotal").textContent = formatPrice(total);
}

// ========================================
// 11. PRODUCT DETAILS
// ========================================

function showProductDetails(productId) {
  selectedProduct = products.find((p) => p.id === productId);

  if (!selectedProduct) return;

  detailQuantity = 1;

  document.getElementById("detailsBody").innerHTML = `

        <div class="details-layout">

            <img src="${selectedProduct.image}" alt="${selectedProduct.name}">

            <div>

                <span class="product-brand">${selectedProduct.brand}</span>

                <h2>${selectedProduct.name}</h2>

                <div class="rating">
                    ${"★".repeat(Math.round(selectedProduct.rating))}
                    <span>${selectedProduct.rating} / 5 Rating</span>
                </div>

                <p><strong>Category:</strong> ${(selectedProduct.categories || [selectedProduct.category]).join(", ")}</p>
                <p>${selectedProduct.description}</p>

                <div class="detail-price">
                    ${formatPrice(selectedProduct.price)} 
                </div>

                <div class="quantity-control">

                    <button id="detailMinus">-</button>

                    <span id="detailQuantity">1</span>

                    <button id="detailPlus">+</button>

                </div>

                <button class="primary-btn" id="detailAdd">
                    <i class="fas fa-shopping-cart"></i> Add to Cart
                </button>

            </div>

        </div>

    `;

  openModal("detailsModal");

  document.getElementById("detailMinus").addEventListener("click", () => {
    if (detailQuantity > 1) {
      detailQuantity--;
      document.getElementById("detailQuantity").textContent = detailQuantity;
    }
  });

  document.getElementById("detailPlus").addEventListener("click", () => {
    detailQuantity++;

    document.getElementById("detailQuantity").textContent = detailQuantity;
  });
  //java mn html button event listner

  document.getElementById("detailAdd").addEventListener("click", () => {
    addToCart(selectedProduct.id, detailQuantity);

    closeModal("detailsModal");
  });
}

// ========================================
// 12. WISHLIST
// ========================================

function toggleWishlist(productId) {
  if (wishlist.includes(productId)) {
    wishlist = wishlist.filter((id) => id !== productId);

    showToast("Removed from wishlist!");
  } else {
    wishlist.push(productId);

    showToast("Added to wishlist!");
  }

  saveWishlist();

  updateWishlistCount();

  filterProducts();
}

function updateWishlistCount() {
  document.getElementById("wishlistCount").textContent = wishlist.length;
}

function renderWishlist() {
  const container = document.getElementById("wishlistItems");

  container.innerHTML = "";

  if (wishlist.length === 0) {
    container.innerHTML =
      '<p class="empty-message">Your wishlist is empty!</p>';

    return;
  }

  wishlist.forEach((id) => {
    const product = products.find((p) => p.id === id);

    if (!product) return;

    const row = document.createElement("div");

    row.className = "wishlist-row";

    row.innerHTML = `

            <img src="${product.image}" alt="${product.name}">

            <div class="wishlist-product-info">
                <h4>${product.name}</h4>
                <p>${formatPrice(product.price)}</p>
                <div class="wishlist-actions">
                    <button class="wishlist-detail-btn" data-details="${product.id}">View Details</button>
                    <button class="wishlist-add-btn" data-add="${product.id}">Add to Cart</button>
                </div>
            </div>

            <button class="wishlist-remove-btn" data-wishlist-remove="${product.id}">
                Remove
            </button>

        `;

    container.appendChild(row);
  });
}

// ========================================
// 13. EVENT DELEGATION
// ========================================

document.addEventListener("click", (event) => {
  const productCard = event.target.closest("[data-product-card]");
  if (productCard && !event.target.closest("button, a, input, select")) {
    showProductDetails(Number(productCard.dataset.productCard));
  }

  const addButton = event.target.closest("[data-add]");

  const detailsButton = event.target.closest("[data-details]");

  const wishlistButton = event.target.closest("[data-wishlist]");

  const cartButton = event.target.closest("[data-cart-action]");

  const removeButton = event.target.closest("[data-remove]");

  const wishlistRemoveButton = event.target.closest("[data-wishlist-remove]");

  if (addButton) {
    addToCart(Number(addButton.dataset.add));
  }

  if (detailsButton) {
    if (detailsButton.closest("#wishlistModal")) closeModal("wishlistModal");
    showProductDetails(Number(detailsButton.dataset.details));
  }

  if (wishlistButton) {
    toggleWishlist(Number(wishlistButton.dataset.wishlist));
  }

  if (cartButton) {
    changeCartQuantity(
      Number(cartButton.dataset.id),
      cartButton.dataset.cartAction,
    );
  }

  if (removeButton) {
    removeFromCart(Number(removeButton.dataset.remove));
  }

  if (wishlistRemoveButton) {
    toggleWishlist(Number(wishlistRemoveButton.dataset.wishlistRemove));

    renderWishlist();
  }
});

// ========================================
// 14. CART AND WISHLIST MODALS
// ========================================

document.getElementById("cartBtn").addEventListener("click", () => {
  renderCart();

  openModal("cartModal");
});

function openWishlist() {
  renderWishlist();

  openModal("wishlistModal");
}

document.getElementById("wishlistBtn").addEventListener("click", openWishlist);

document.getElementById("drawerWishlist").addEventListener("click", (event) => {
  event.preventDefault();

  closeDrawer();

  openWishlist();
});

document.getElementById("footerWishlist").addEventListener("click", (event) => {
  event.preventDefault();

  openWishlist();
});

// ========================================
// 15. NAVIGATION DRAWER
// ========================================

const drawer = document.getElementById("drawer");

const overlay = document.getElementById("overlay");

function openDrawer() {
  drawer.classList.add("open");

  overlay.classList.add("show");
}

function closeDrawer() {
  drawer.classList.remove("open");

  overlay.classList.remove("show");
}

document.getElementById("menuBtn").addEventListener("click", openDrawer);

document.getElementById("closeDrawer").addEventListener("click", closeDrawer);

overlay.addEventListener("click", closeDrawer);

drawer.querySelectorAll('a[href^="#"]:not([id])').forEach((link) => {
  link.addEventListener("click", closeDrawer);
});

// ========================================
// 16. IMAGE SLIDESHOW
// ========================================

const slides = document.querySelectorAll(".slide");

const dotsContainer = document.getElementById("slideDots");

function createDots() {
  dotsContainer.innerHTML = "";

  slides.forEach((slide, index) => {
    const dot = document.createElement("button");

    dot.className = "dot";

    dot.setAttribute("aria-label", "Go to slide " + (index + 1));

    dot.addEventListener("click", () => {
      showSlide(index);

      startSlideshow();
    });

    dotsContainer.appendChild(dot);
  });
}

function showSlide(index) {
  currentSlide = (index + slides.length) % slides.length;

  slides.forEach((slide, i) => {
    slide.classList.toggle("active", i === currentSlide);
  });

  document.querySelectorAll(".dot").forEach((dot, i) => {
    dot.classList.toggle("active", i === currentSlide);
  });
}

function nextSlide() {
  showSlide(currentSlide + 1);
}

function previousSlide() {
  showSlide(currentSlide - 1);
}

function startSlideshow() {
  clearInterval(slideTimer);

  slideTimer = setInterval(nextSlide, 4000);
}

document.getElementById("nextSlide").addEventListener("click", () => {
  nextSlide();

  startSlideshow();
});

document.getElementById("prevSlide").addEventListener("click", () => {
  previousSlide();

  startSlideshow();
});

createDots();

showSlide(0);

startSlideshow();

// ========================================
// 17. LOGIN AND SIGNUP
// ========================================

function updateUserInterface() {
  if (currentUser) {
    document.getElementById("drawerUser").textContent = currentUser.name;

    document.getElementById("loginBtn").innerHTML =
      '<i class="fas fa-user-check"></i><span>Account</span>';
  } else {
    document.getElementById("drawerUser").textContent = "Welcome Guest";

    document.getElementById("loginBtn").innerHTML =
      '<i class="far fa-user"></i><span>Login</span>';
  }
}

function openAuth() {
  openModal("authModal");
}

document.getElementById("loginBtn").addEventListener("click", openAuth);

document.getElementById("navLogin").addEventListener("click", (event) => {
  event.preventDefault();

  openAuth();
});

document.querySelectorAll(".auth-tab").forEach((button) => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".auth-tab").forEach((tab) => {
      tab.classList.remove("active");
    });

    button.classList.add("active");

    const isLogin = button.dataset.auth === "login";

    document.getElementById("loginForm").hidden = !isLogin;

    document.getElementById("signupForm").hidden = isLogin;
  });
});

// Signup form validation

document.getElementById("signupForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const name = document.getElementById("signupName").value.trim();

  const email = document.getElementById("signupEmail").value.trim();

  const password = document.getElementById("signupPassword").value;

  const confirm = document.getElementById("confirmPassword").value;

  if (name.length < 3) {
    showToast("Name must contain at least 3 characters!");

    return;
  }

  if (password.length < 6) {
    showToast("Password must have at least 6 characters!");

    return;
  }

  if (password !== confirm) {
    showToast("Passwords do not match!");

    return;
  }

  const users = JSON.parse(localStorage.getItem("shopEaseUsers")) || [];

  if (users.some((user) => user.email.toLowerCase() === email.toLowerCase())) {
    showToast("This email is already registered!");

    return;
  }

  users.push({
    name: name,
    email: email,
    password: password,
  });

  localStorage.setItem("shopEaseUsers", JSON.stringify(users));

  showToast("Account created successfully!");

  document.getElementById("signupForm").reset();

  document.querySelector('[data-auth="login"]').click();

  document.getElementById("loginEmail").value = email;
});

// Login form validation

document.getElementById("loginForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const email = document.getElementById("loginEmail").value.trim();

  const password = document.getElementById("loginPassword").value;

  const users = JSON.parse(localStorage.getItem("shopEaseUsers")) || [];

  const user = users.find(
    (item) =>
      item.email.toLowerCase() === email.toLowerCase() &&
      item.password === password,
  );

  if (!user) {
    showToast("Invalid email or password!");

    return;
  }

  currentUser = {
    name: user.name,
    email: user.email,
  };

  localStorage.setItem("shopEaseUser", JSON.stringify(currentUser));

  updateUserInterface();

  document.getElementById("loginForm").reset();

  closeModal("authModal");

  showToast("Welcome back, " + user.name + "!");
});

// Logout

document.getElementById("logoutBtn").addEventListener("click", (event) => {
  event.preventDefault();

  if (!currentUser) {
    closeDrawer();

    showToast("You are already logged out!");

    return;
  }

  currentUser = null;

  localStorage.removeItem("shopEaseUser");

  updateUserInterface();

  closeDrawer();

  showToast("Logged out successfully!");
});

// ========================================
// 18. PROFILE, ORDERS AND SETTINGS
// ========================================

document.getElementById("profileLink").addEventListener("click", (event) => {
  event.preventDefault();

  closeDrawer();

  if (!currentUser) {
    openAuth();

    return;
  }

  alert(
    "My Profile\n\nName: " + currentUser.name + "\nEmail: " + currentUser.email,
  );
});

function showOrders() {
  closeDrawer();

  if (!currentUser) {
    openAuth();

    showToast("Please login to view your orders!");

    return;
  }

  alert("You have no previous orders yet.");
}

document.getElementById("ordersLink").addEventListener("click", (event) => {
  event.preventDefault();

  showOrders();
});

document.getElementById("footerOrders").addEventListener("click", (event) => {
  event.preventDefault();

  showOrders();
});

document.getElementById("settingsLink").addEventListener("click", (event) => {
  event.preventDefault();

  closeDrawer();

  alert("ShopEase Settings\n\nAccount and shopping preferences.");
});

// ========================================
// 19. CHECKOUT
// ========================================

document.getElementById("checkoutBtn").addEventListener("click", () => {
  if (cart.length === 0) {
    showToast("Your cart is empty!");

    return;
  }

  if (!currentUser) {
    closeModal("cartModal");

    openAuth();

    showToast("Please login before checkout!");

    return;
  }

  alert(
    "Thank you for shopping with ShopEase!\n\n" +
      "Your demo order has been placed successfully.",
  );

  cart = [];

  saveCart();

  updateCartCount();

  renderCart();

  closeModal("cartModal");

  showToast("Demo order placed successfully!");
});

// ========================================
// 20. NEWSLETTER
// ========================================

document
  .getElementById("newsletterForm")
  .addEventListener("submit", (event) => {
    event.preventDefault();

    const email = document.getElementById("newsletterEmail").value.trim();

    if (!email) {
      showToast("Please enter your email!");

      return;
    }

    showToast("Thank you for subscribing!");

    event.target.reset();
  });

// ========================================
// 21. MODAL CLOSE BUTTONS
// ========================================

document.querySelectorAll("[data-close]").forEach((button) => {
  button.addEventListener("click", () => {
    closeModal(button.dataset.close);
  });
});

document.querySelectorAll(".modal").forEach((modal) => {
  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      closeModal(modal.id);
    }
  });
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    document.querySelectorAll(".modal.show").forEach((modal) => {
      closeModal(modal.id);
    });

    closeDrawer();
  }
});

// ========================================
// 22. INITIALIZE WEBSITE
// ========================================

function initializeWebsite() {
  renderProducts(products);

  updateCartCount();

  updateWishlistCount();

  updateUserInterface();

  console.log("ShopEase Website Loaded Successfully!");

  console.log("Total Products:", products.length);

  console.log("Shopping Cart:", cart);

  console.log("Wishlist:", wishlist);
}

initializeWebsite();


// Keyboard support for clickable product and category cards.
document.addEventListener("keydown", (event) => {
  if (event.key !== "Enter" && event.key !== " ") return;
  const productCard = event.target.closest("[data-product-card]");
  const categoryCard = event.target.closest(".category-card");
  if (productCard && event.target === productCard) {
    event.preventDefault();
    showProductDetails(Number(productCard.dataset.productCard));
  }
  if (categoryCard && event.target === categoryCard) {
    event.preventDefault();
    categoryCard.click();
  }
});